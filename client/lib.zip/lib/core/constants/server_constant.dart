class ServerConstant {
  static const String serverUrl = 'http://192.168.122.1:8000';
}
