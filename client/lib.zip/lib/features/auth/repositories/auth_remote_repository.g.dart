// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_remote_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authRemoteRepositoryHash() =>
    r'3a22426af88879347e1278f66bf786f109bd891c';

/// See also [authRemoteRepository].
@ProviderFor(authRemoteRepository)
final authRemoteRepositoryProvider =
    AutoDisposeProvider<AuthRemoteRepository>.internal(
      authRemoteRepository,
      name: r'authRemoteRepositoryProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$authRemoteRepositoryHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AuthRemoteRepositoryRef = AutoDisposeProviderRef<AuthRemoteRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
